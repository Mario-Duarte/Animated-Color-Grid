/**
 * Created by marioduarte on 30/03/15.
 */
$(document).ready(function () {

    (function() {

        // create variables
        var cards = document.querySelectorAll(".grid-item.effect__fade");
        var colorGrid = document.getElementById("color-grid");
        var timeMin = colorGrid.getAttribute('data-time-min');
        var timeMax = colorGrid.getAttribute('data-time-max');
        var timeouts = [];

        // loop through cards
        for ( var i = 0, len = cards.length; i < len; i++ ) {
            var card = cards[i];
            var cardID = card.getAttribute("data-id");
            var id = "timeoutID" + cardID;
            var time = randomNum( timeMin, timeMax ) * 1000;
            cardsTimeout( id, time, card );
        }

        // timeout listener
        function cardsTimeout( id, time, card ) {
            if (id in timeouts) {
                clearTimeout(timeouts[id]);
            }
            timeouts[id] = setTimeout( function() {
                var c = card.classList;
                var newTime = randomNum( timeMin, timeMax ) * 1000;
                c.contains("faded") === true ? c.remove("faded") : c.add("faded");
                cardsTimeout( id, newTime, card );
            }, time );
        }

        // random number generator given min and max
        function randomNum( min, max ) {
            return Math.random() * (max - min) + min;
        }

    })();

});